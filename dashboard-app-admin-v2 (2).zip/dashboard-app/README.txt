DASHBOARD LOGIN, DAFTAR, ADMIN & USER
=====================================

CARA MENJALANKAN
1. Pasang Node.js (https://nodejs.org), versi 16 ke atas.
2. Ekstrak zip ini, buka terminal di folder hasil ekstrak.
3. Jalankan:  node server.js
4. Buka di browser:  http://localhost:3000
   (Jangan buka dashboard.html dengan klik dua kali, form tidak akan terhubung ke server.)

AKUN UJI COBA
- Admin       : username  admin   | password  Admin#2026
- User lokal  : username  user1   | password  User#1234
Ganti password admin sebelum dipakai sungguhan.

ISI FOLDER
- dashboard.html           Tampilan: login, daftar, beranda user, beranda admin
- server.js                Server Node.js (tanpa paket tambahan)
- DaftarAccount.js         Data akun user yang mendaftar (diisi otomatis oleh server)
- admin/AdminAccount.js    Akun admin (folder ini tidak bisa dibuka lewat browser)
- admin/BerandaUser.js     Pengaturan beranda user (diatur dari beranda admin)

FITUR
- Satu halaman login untuk admin dan user. Server mengenali peran dari akunnya.
- Daftar: Nama, No telepon, Email (ditambah Username dan Password untuk login).
- Password disimpan dalam bentuk acak (scrypt + salt), bukan teks asli.

BERANDA USER LOKAL (hanya melihat)
- Data dirinya, kalimat sambutan, dan pengumuman.

BERANDA ADMIN (mengatur semuanya)
- Ringkasan : total akun, daftar hari ini, pendaftar terbaru.
- Kelola Akun : edit nama/telepon/email/password, hapus akun.
- Atur Beranda User : judul sapaan, sambutan, pengumuman, wallpaper foto/video.
  Wallpaper: isi nama file (contoh wallpaper.jpg atau wallpaper.mp4), file ditaruh
  di folder yang sama dengan server.js.

KEAMANAN
- Semua aksi admin dicek di server. User biasa ditolak (403), tanpa login ditolak (401).
- Sesi login hilang saat server dimatikan, admin perlu masuk lagi.
- Ini cocok untuk uji coba lokal. Untuk dipakai di internet, tambahkan HTTPS,
  batas percobaan login, dan database sungguhan.


FITUR ADMIN TERBARU
- Dashboard admin berbeda dari dashboard user biasa.
- Login tetap memakai satu halaman login, tetapi server otomatis mengenali role.
- Kredensial admin hanya berasal dari admin/AdminAccount.js.
- Admin dapat menambah User Lokal dari menu "Tambah User".
- Admin dapat melihat daftar admin dari menu "Kelola Admin".
- Admin dapat menambah Admin baru; akun otomatis disimpan ke admin/AdminAccount.js.
- Username tidak boleh sama antara user dan admin.
- Password user/admin baru tidak disimpan sebagai teks asli, tetapi di-hash dengan scrypt + salt.
