// Akun admin. Folder ini tidak bisa dibuka lewat browser.
module.exports = [
  {
    "nama": "Administrator",
    "username": "admin",
    "pass": "7af16d6a57a847e3e1594be84dc033e64d420e79f2f829f6cb5e6c8a49208db1",
    "salt": "a929ae953b230170c6180ae82609581f"
  }
];
