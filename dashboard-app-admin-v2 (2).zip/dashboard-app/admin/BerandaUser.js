// Pengaturan beranda user. Diatur dari beranda admin
module.exports = {
  "judul": "Halo",
  "sambutan": "Selamat datang di dashboard Anda.",
  "pengumuman": [
    "Selamat bergabung!"
  ],
  "wallpaper": {
    "type": "image",
    "src": ""
  }
};
