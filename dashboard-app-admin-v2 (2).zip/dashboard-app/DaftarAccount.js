// Data akun terdaftar. Dibuat otomatis oleh server.js
module.exports = [
  {
    "nama": "User Uji Coba",
    "telp": "081234567890",
    "email": "user.uji@example.com",
    "username": "user1",
    "pass": "0c9dbfea671e4ea7534db1940cb6f2374d94734059590409aba755033ac782ae",
    "dibuat": "2026-10-07T00:00:00.000Z",
    "salt": "1a229f0d30df9c4030da6c85e896866a"
  }
];
