// Jalankan: node server.js  -> buka http://localhost:3000
const http = require('http'), fs = require('fs'), path = require('path'), crypto = require('crypto');
const PORT = 3000;
const DB = path.join(__dirname, 'DaftarAccount.js');
const ADMIN_DIR = path.join(__dirname, 'admin');
const ADMIN_DB = path.join(ADMIN_DIR, 'AdminAccount.js');
const BERANDA_DB = path.join(ADMIN_DIR, 'BerandaUser.js');
const HIDDEN = ['daftaraccount.js', 'server.js'];
const MIME = {'.html':'text/html; charset=utf-8','.js':'text/javascript','.css':'text/css','.jpg':'image/jpeg','.jpeg':'image/jpeg','.png':'image/png','.webp':'image/webp','.gif':'image/gif','.mp4':'video/mp4','.webm':'video/webm'};
const DEFAULT_BERANDA = {judul:'Halo', sambutan:'Selamat datang di dashboard Anda.', pengumuman:[], wallpaper:{type:'image', src:''}};
const sessions = new Map(); // token -> {role, username}; hilang saat server restart

function readJS(file, fallback, open, close){
  try{ const t = fs.readFileSync(file, 'utf8'); return JSON.parse(t.slice(t.indexOf(open), t.lastIndexOf(close) + 1)); }
  catch(e){ return fallback; }
}
function writeJS(file, data, note){
  fs.mkdirSync(path.dirname(file), {recursive:true});
  fs.writeFileSync(file, '// ' + note + '\nmodule.exports = ' + JSON.stringify(data, null, 2) + ';\n');
}
const readDB = (f = DB) => readJS(f, [], '[', ']');
const saveUsers = list => writeJS(DB, list, 'Data akun terdaftar. Dibuat otomatis oleh server.js');
const readBeranda = () => ({...DEFAULT_BERANDA, ...readJS(BERANDA_DB, {}, '{', '}')});
const hashPass = (p, salt) => crypto.scryptSync(p, salt, 32).toString('hex');
const publicUser = u => ({nama:u.nama, telp:u.telp, email:u.email, username:u.username});
const okTelp = t => /^[0-9+\-\s]{8,16}$/.test(t), okEmail = e => /^\S+@\S+\.\S+$/.test(e);
const str = (v, max) => String(v == null ? '' : v).trim().slice(0, max);

function send(res, code, obj){ res.writeHead(code, {'Content-Type':'application/json'}); res.end(JSON.stringify(obj)); }
function body(req){
  return new Promise((ok, no) => {
    let d = ''; req.on('data', c => { d += c; if(d.length > 1e5){ no(); req.destroy(); } });
    req.on('end', () => { try{ ok(JSON.parse(d || '{}')); }catch(e){ no(); } });
  });
}

async function api(req, res, url){
  const key = req.method + ' ' + url;
  let b = {};
  if(req.method === 'POST'){ try{ b = await body(req); }catch(e){ return send(res, 400, {error:'Data tidak valid.'}); } }
  const sess = sessions.get((req.headers.authorization || '').replace('Bearer ', ''));

  // ---------- Umum ----------
  if(key === 'GET /api/beranda') return send(res, 200, readBeranda());

  if(key === 'POST /api/daftar'){
    const nama = str(b.nama, 80), telp = str(b.telp, 20), email = str(b.email, 120);
    const username = str(b.username, 30).toLowerCase(), pass = String(b.pass || '');
    if(!nama || !okTelp(telp) || !okEmail(email) || username.length < 3 || pass.length < 6)
      return send(res, 400, {error:'Data belum lengkap atau formatnya salah.'});
    const list = readDB();
    if(list.some(u => u.username === username) || readDB(ADMIN_DB).some(a => a.username === username))
      return send(res, 409, {error:'Username sudah dipakai. Pilih username lain.'});
    const salt = crypto.randomBytes(16).toString('hex');
    list.push({nama, telp, email, username, salt, pass:hashPass(pass, salt), dibuat:new Date().toISOString()});
    saveUsers(list);
    return send(res, 200, {ok:true});
  }

  if(key === 'POST /api/login'){
    const uname = str(b.username, 30).toLowerCase(), pass = String(b.pass || '');
    const gagal = {error:'Username atau password salah. Periksa lagi, atau daftar bila belum punya akun.'};
    const adm = readDB(ADMIN_DB).find(x => x.username === uname);
    if(adm){
      if(hashPass(pass, adm.salt) !== adm.pass) return send(res, 401, gagal);
      const token = crypto.randomBytes(24).toString('hex');
      sessions.set(token, {role:'admin', username:adm.username});
      return send(res, 200, {ok:true, role:'admin', token, user:{nama:adm.nama, username:adm.username}});
    }
    const u = readDB().find(x => x.username === uname);
    if(!u || hashPass(pass, u.salt) !== u.pass) return send(res, 401, gagal);
    const token = crypto.randomBytes(24).toString('hex');
    sessions.set(token, {role:'user', username:u.username});
    return send(res, 200, {ok:true, role:'user', token, user:publicUser(u)});
  }

  // ---------- Khusus admin: user biasa selalu ditolak ----------
  if(url.startsWith('/api/admin/')){
    if(!sess) return send(res, 401, {error:'Sesi tidak valid. Silakan masuk lagi.'});
    if(sess.role !== 'admin') return send(res, 403, {error:'Hanya admin yang boleh mengakses ini.'});

    if(key === 'GET /api/admin/users')
      return send(res, 200, {ok:true, users:readDB().map(u => ({...publicUser(u), dibuat:u.dibuat}))});

    if(key === 'POST /api/admin/user/edit'){
      const list = readDB(), u = list.find(x => x.username === str(b.username, 30).toLowerCase());
      if(!u) return send(res, 404, {error:'Akun tidak ditemukan.'});
      const nama = str(b.nama, 80), telp = str(b.telp, 20), email = str(b.email, 120), pass = String(b.pass || '');
      if(!nama || !okTelp(telp) || !okEmail(email) || (pass && pass.length < 6))
        return send(res, 400, {error:'Data belum lengkap atau formatnya salah.'});
      Object.assign(u, {nama, telp, email});
      if(pass){ u.salt = crypto.randomBytes(16).toString('hex'); u.pass = hashPass(pass, u.salt); }
      saveUsers(list);
      return send(res, 200, {ok:true});
    }

    if(key === 'POST /api/admin/user/hapus'){
      const name = str(b.username, 30).toLowerCase(), list = readDB();
      if(!list.some(x => x.username === name)) return send(res, 404, {error:'Akun tidak ditemukan.'});
      saveUsers(list.filter(x => x.username !== name));
      for(const [t, s] of sessions) if(s.username === name) sessions.delete(t);
      return send(res, 200, {ok:true});
    }

    // Tambah akun USER biasa dari panel admin
    if(key === 'POST /api/admin/user/tambah'){
      const nama = str(b.nama, 80), telp = str(b.telp, 20), email = str(b.email, 120);
      const username = str(b.username, 30).toLowerCase(), pass = String(b.pass || '');
      if(!nama || !okTelp(telp) || !okEmail(email) || username.length < 3 || pass.length < 6)
        return send(res, 400, {error:'Data user belum lengkap atau formatnya salah.'});
      const users = readDB(), admins = readDB(ADMIN_DB);
      if(users.some(u => u.username === username) || admins.some(a => a.username === username))
        return send(res, 409, {error:'Username sudah dipakai.'});
      if(users.some(u => u.email.toLowerCase() === email.toLowerCase()))
        return send(res, 409, {error:'Email user sudah dipakai.'});
      const salt = crypto.randomBytes(16).toString('hex');
      users.push({nama, telp, email, username, salt, pass:hashPass(pass, salt), dibuat:new Date().toISOString()});
      saveUsers(users);
      return send(res, 200, {ok:true, user:publicUser(users[users.length - 1])});
    }

    // Tambah ADMIN. Kredensial admin hanya disimpan di AdminAccount.js.
    if(key === 'POST /api/admin/admin/tambah'){
      const nama = str(b.nama, 80), username = str(b.username, 30).toLowerCase(), pass = String(b.pass || '');
      if(!nama || username.length < 3 || pass.length < 6)
        return send(res, 400, {error:'Nama, username minimal 3 karakter, dan password minimal 6 karakter wajib diisi.'});
      const admins = readDB(ADMIN_DB), users = readDB();
      if(admins.some(a => a.username === username) || users.some(u => u.username === username))
        return send(res, 409, {error:'Username sudah dipakai.'});
      const salt = crypto.randomBytes(16).toString('hex');
      admins.push({nama, username, pass:hashPass(pass, salt), salt});
      writeJS(ADMIN_DB, admins, 'Akun admin. Folder ini tidak bisa dibuka lewat browser.');
      return send(res, 200, {ok:true, admin:{nama, username}});
    }

    // Daftar admin untuk ditampilkan di panel admin (password tidak pernah dikirim)
    if(key === 'GET /api/admin/admins')
      return send(res, 200, {ok:true, admins:readDB(ADMIN_DB).map(a => ({nama:a.nama, username:a.username}))});

    if(key === 'POST /api/admin/beranda'){
      const w = b.wallpaper || {}, src = str(w.src, 300);
      const data = {
        judul: str(b.judul, 80) || 'Halo',
        sambutan: str(b.sambutan, 300),
        pengumuman: (Array.isArray(b.pengumuman) ? b.pengumuman : []).map(x => str(x, 200)).filter(Boolean).slice(0, 20),
        wallpaper: {type: w.type === 'video' ? 'video' : 'image', src: /^\s*javascript:/i.test(src) ? '' : src}
      };
      writeJS(BERANDA_DB, data, 'Pengaturan beranda user. Diatur dari beranda admin');
      return send(res, 200, {ok:true, beranda:data});
    }
  }
  return send(res, 404, {error:'Tidak ditemukan.'});
}

http.createServer(async (req, res) => {
  const url = decodeURIComponent(req.url.split('?')[0]);
  if(url.startsWith('/api/')) return api(req, res, url);
  const f = path.join(__dirname, url === '/' ? 'dashboard.html' : url);
  if(!f.startsWith(__dirname) || f.startsWith(ADMIN_DIR) || HIDDEN.includes(path.basename(f).toLowerCase())){
    res.writeHead(403); return res.end('Dilarang');
  }
  fs.readFile(f, (err, data) => {
    if(err){ res.writeHead(404); return res.end('Tidak ditemukan'); }
    res.writeHead(200, {'Content-Type': MIME[path.extname(f).toLowerCase()] || 'application/octet-stream'});
    res.end(data);
  });
}).listen(PORT, () => console.log('Dashboard jalan di http://localhost:' + PORT));
